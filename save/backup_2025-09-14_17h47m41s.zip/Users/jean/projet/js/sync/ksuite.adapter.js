/* ksuite.adapter.js — placeholder (non appelé pour l'instant) */
(function(g){ g.KsuiteAdapter = g.KsuiteAdapter || {
  async pull(){ return {clients:[],contacts:[]}; },
  async push(_changes){ /* no-op */ },
  _v:'placeholder'
}; })(window);