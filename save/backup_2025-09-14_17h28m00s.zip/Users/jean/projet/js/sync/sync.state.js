/* sync.state.js — placeholder (non appelé pour l'instant) */
(function(g){ g.SyncState = g.SyncState || {
  get(_k){ return null; }, set(_k,_v){ /* no-op */ }, _v:'placeholder'
}; })(window);